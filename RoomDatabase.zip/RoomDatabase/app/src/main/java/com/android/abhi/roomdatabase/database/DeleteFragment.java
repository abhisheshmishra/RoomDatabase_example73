package com.android.abhi.roomdatabase.database;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.android.abhi.roomdatabase.MainClass;
import com.android.abhi.roomdatabase.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class DeleteFragment extends Fragment {
    EditText user_id;

    Button save;


    public DeleteFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_delete, container, false);

        user_id = view.findViewById(R.id.user_id);
        save = view.findViewById(R.id.save);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id = Integer.parseInt(user_id.getText().toString());

                Repo repo = new Repo();
                repo.setId(id);

                MainClass.appDatabase.repoDao().delete(repo);

                Toast.makeText(getActivity(), "Deleted Successfully", Toast.LENGTH_LONG).show();

                user_id.setText("");

            }
        });
        return view;
    }

}
