package com.android.abhi.roomdatabase.database;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

@Database(entities = {Repo.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    public abstract RepoDao repoDao();
}
