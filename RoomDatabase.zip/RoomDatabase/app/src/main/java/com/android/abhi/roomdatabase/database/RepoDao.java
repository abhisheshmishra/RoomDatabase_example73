package com.android.abhi.roomdatabase.database;

import android.arch.persistence.room.*;

import java.util.List;

@Dao
public interface RepoDao {

    @Insert
    public void insert(Repo task);

    @Delete
    public void delete(Repo task);

    @Update
    public void update(Repo task);

    @Query("select * from Repo")
    public List<Repo> getuser();

}
