package com.android.abhi.roomdatabase.database;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.TextView;
import com.android.abhi.roomdatabase.MainClass;
import com.android.abhi.roomdatabase.R;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class ReadInfoFragment extends Fragment {

    TextView user_info;


    public ReadInfoFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_read_info, container, false);

        user_info = view.findViewById(R.id.user_info);

        List<Repo> repos = MainClass.appDatabase.repoDao().getuser();

        String info = "";


        for (Repo repo : repos) {

            int id = repo.getId();
            String name = repo.getName();
            String email = repo.getEmail();

            info = info + "\n\n" + "id :" + id + "\n" + "Name :" + name + "\n" + "Email :" + email;

        }
        user_info.setText(info);

        return view;
    }

}
