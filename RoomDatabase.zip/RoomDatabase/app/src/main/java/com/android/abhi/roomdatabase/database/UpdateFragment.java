package com.android.abhi.roomdatabase.database;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.android.abhi.roomdatabase.MainClass;
import com.android.abhi.roomdatabase.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class UpdateFragment extends Fragment implements View.OnClickListener {

    private EditText user_name, user_id, user_email;
    private Button save;

    public UpdateFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_update, container, false);
        user_name = view.findViewById(R.id.user_name);
        user_id = view.findViewById(R.id.user_id);
        user_email = view.findViewById(R.id.user_email);
        save = view.findViewById(R.id.save);
        save.setOnClickListener(this);


        return view;
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.save:
                update();
                break;
        }
    }

    public void update() {
        int userid = Integer.parseInt(user_id.getText().toString());
        String username = user_name.getText().toString();
        String useremail = user_email.getText().toString();

        Repo repo = new Repo();
        repo.setEmail(useremail);
        repo.setId(userid);
        repo.setName(username);


        MainClass.appDatabase.repoDao().update(repo);
        Toast.makeText(getActivity(),"updated Successfully",Toast.LENGTH_LONG).show();

        user_id.setText("");
        user_name.setText("");
        user_email.setText("");

    }

}
